import UIKit

class Person
{
    let name: String
    
    init (name: String)
    {
        self.name = name
    }
    
    func sayHello()
    {
        print ("hello there!")
        

    }
}


let person = Person(name: "Cesar")
print(person.name)
person.sayHello()

class Vehicle
{
    var currentSpeed = 0.0
    
    var description : String
    {
        return "traveling at \(currentSpeed) miles per hour"
    }
    
    func makeNoise()
    {
        //no todos los vehiculos hacen ruiditos
    }
}

